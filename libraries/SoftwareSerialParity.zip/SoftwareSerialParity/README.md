# SoftwareSerialParity
This is an Arduino Library for defining Software Serial pins and adding parity to the serial protocol
